# SOVERINT

Soverint - mission-based AI workspace skeleton.

This repo is scaffolded for local-first, client-heavy application using IndexedDB.
See /docs for architecture and flow notes.
