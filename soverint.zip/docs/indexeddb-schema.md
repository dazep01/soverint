# IndexedDB Schema

Runtime storage contract (mission drafts, runtime state).
