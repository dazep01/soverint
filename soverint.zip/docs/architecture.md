# Architecture

High level architecture notes for Soverint.
