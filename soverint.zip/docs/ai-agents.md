# AI Agents

Agent archetypes, specializations, and recruitment UI notes.
