# Workflow Intelligence

Notes about soverint_workflow_intelligence.json and phase mapping.
