import { useEffect, useRef, useState, ReactNode } from "react";
import anime from "animejs";

interface AppShellProps {
  children: ReactNode; // Gunakan ReactNode untuk tipe children
}

export default function AppShell({ children }: AppShellProps) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const [activeIndex, setActiveIndex] = useState(1); // Default ke Command Center (index 1)

  // Fungsi untuk update layout dan highlight button
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    // Animasi perpindahan panel
    anime({
      targets: track,
      translateX: `-${activeIndex * 100}%`,
      duration: 600,
      easing: "cubicBezier(0.2, 0.8, 0.2, 1)",
    });

    // Update active button
    document.querySelectorAll(".nav-btn").forEach((btn) => {
      btn.classList.remove("active");
    });

    // Ambil ID panel aktif dari urutan (asumsi urutan panel sesuai dengan urutan button)
    const panelIds = ['panel-magnify', 'panel-misi', 'panel-agents', 'panel-gear'];
    const targetPanelId = panelIds[activeIndex];
    if (targetPanelId) {
      const activeBtn = document.querySelector(
        `.nav-btn[data-target="${targetPanelId}"]`
      ) as HTMLElement;
      if (activeBtn) activeBtn.classList.add("active");
    }
  }, [activeIndex]);

  // Handler untuk klik navigasi
  const handleNavClick = (targetId: string) => {
    const panelIds = ['panel-magnify', 'panel-misi', 'panel-agents', 'panel-gear'];
    const index = panelIds.indexOf(targetId);
    if (index !== -1) setActiveIndex(index);
  };

  // Handler untuk resize
  useEffect(() => {
    const handleResize = () => {
      const track = trackRef.current;
      if (track) {
        track.style.transform = `translateX(-${activeIndex * 100}%)`;
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [activeIndex]);

  return (
    <>
      {/* Panel Track (ini adalah konten utama) */}
      <div ref={trackRef} className="panels-track" id="panelsTrack">
        {children}
      </div>

      {/* Navigation Bar */}
      <nav className="nav-bar">
        <div className="nav-track">
          <button
            className="nav-btn"
            data-target="panel-magnify"
            onClick={() => handleNavClick('panel-magnify')}
          >
            <i className="ph ph-magnifying-glass"></i>
          </button>
          
          <button
            className="nav-btn"
            data-target="panel-misi"
            onClick={() => handleNavClick('panel-misi')}
          >
            <i className="ph ph-squares-four"></i>
          </button>
          
          <button className="nav-btn fab" id="fabAction">
            <i className="ph ph-plus"></i>
          </button>
          
          <button
            className="nav-btn"
            data-target="panel-agents"
            onClick={() => handleNavClick('panel-agents')}
          >
            <i className="ph ph-users-four"></i>
          </button>
          
          <button
            className="nav-btn"
            data-target="panel-gear"
            onClick={() => handleNavClick('panel-gear')}
          >
            <i className="ph ph-gear"></i>
          </button>
          
          <div className="nav-indicator"></div>
        </div>
      </nav>
    </>
  );
}